package day01;

public class HelloJava {

	public static void main(String[] args) {
		// \n은 줄바꿈 명령
		/* 주석은 프록램 코드에 영향을 미치지 않습니다. */
		System.out.print("hello 자바!!\n");
		System.out.print("안녕하세요!?\n");

	}
}