/**
 * 
 */
/**
 * 
 */
module JavaQuiz {
}